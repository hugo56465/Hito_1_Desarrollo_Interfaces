
public class Montana_rusa extends Atraccion{
	private int velocidadMaxima;

	public Montana_rusa(int numeroSerie, String nombre, ParqueAtracciones parqueAtracciones) {
		super(numeroSerie, nombre, parqueAtracciones);
		this.velocidadMaxima = velocidadMaxima;
	}

	public int getVelocidadMaxima() {
		return velocidadMaxima;
	}

	public void setVelocidadMaxima(int velocidadMaxima) {
		this.velocidadMaxima = velocidadMaxima;
	}

	@Override
	public String toString() {
		return "Montaña_rusa\n"+super.toString()+ "[velocidadMaxima=" + velocidadMaxima + "]";
	}
	
}
