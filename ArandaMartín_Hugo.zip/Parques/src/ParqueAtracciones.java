
public class ParqueAtracciones {
	private String nombre;
    private String ciudad;
    private int anoFundacion;
	public ParqueAtracciones(String nombre, String ciudad, int anoFundacion) {
		super();
		this.nombre = nombre;
		this.ciudad = ciudad;
		this.anoFundacion = anoFundacion;
	}
	public String getNombre() {
		return nombre;
	}
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	public String getCiudad() {
		return ciudad;
	}
	public void setCiudad(String ciudad) {
		this.ciudad = ciudad;
	}
	public int getAnoFundacion() {
		return anoFundacion;
	}
	public void setAnoFundacion(int anoFundacion) {
		this.anoFundacion = anoFundacion;
	}
    
}
