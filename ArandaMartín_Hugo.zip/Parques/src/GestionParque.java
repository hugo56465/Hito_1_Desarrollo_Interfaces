import java.util.ArrayList;
import java.util.List;

public class GestionParque {
	private List<Atraccion> listaAtracciones;

	public GestionParque() {
		super();
		this.listaAtracciones = new ArrayList<>();
	}
	public boolean agregarAtraccion(Atraccion atraccion) {
		for(Atraccion a: listaAtracciones) {
			if(a.getNumeroSerie()==atraccion.getNumeroSerie()) {
				return false;
			}
		}
		listaAtracciones.add(atraccion);
		return true;
	}
	public Atraccion obtenerAtraccionPorNumeroDeSerie(int numeroSerie) {
		for(Atraccion atraccion: listaAtracciones) {
			if(atraccion.getNumeroSerie()==numeroSerie) {
				return atraccion;
			}
		}
		return null;
	}
	public void incrementarVisitantes(int numeroSerie,int cantidad) {
		Atraccion atraccion=obtenerAtraccionPorNumeroDeSerie(numeroSerie);
		if(atraccion!=null){
			atraccion.incrementarVisitantes(cantidad);
		}
	}
	public int obtenerNumeroTotalMontanasRusa() {
		int totalMontanaRusa=0;
		for(Atraccion atraccion:listaAtracciones) {
			if(atraccion instanceof Montana_rusa) {
				totalMontanaRusa++;
			}
		}
		return totalMontanaRusa;
	}
	public int obtenerVelocidadMaximaMontanaRusa() {
		int velocidadMaxima=0;
		for(Atraccion atraccion:listaAtracciones) {
			if(atraccion instanceof Montana_rusa) {
				Montana_rusa montaña_rusa=(Montana_rusa) atraccion;
				velocidadMaxima=Math.max(velocidadMaxima, montaña_rusa.getVelocidadMaxima());
			}
		}
		return velocidadMaxima;
	}
}
