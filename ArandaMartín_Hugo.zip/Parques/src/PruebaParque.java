

public class PruebaParque {
    public static void main(String[] args) {
        GestionParque gestionParque = new GestionParque();
        Montana_rusa dragonKhan = new Montana_rusa(12344, "Dragon Khan", new ParqueAtracciones("PortAventura", "Tarragona", 1995));
        boolean altaMontanaRusa = gestionParque.agregarAtraccion(dragonKhan);
        if (altaMontanaRusa) {
            System.out.println("Se ha dado de alta con el número de serie " + dragonKhan.getNumeroSerie());
        } else {
        	System.out.println("No se ha dado de alta con el número de serie " + dragonKhan.getNumeroSerie());
        }
        Noria noriaInfantil = new Noria(56789, "Noria Infantil", new ParqueAtracciones("Parque Divertido", "Ciudad Divertida", 2000), 0, Noria.TipoNoria.INFANTIL);
        boolean altaNoria = gestionParque.agregarAtraccion(noriaInfantil);
        if (altaNoria) {
            System.out.println("Se ha dado de alta con el número de serie " + noriaInfantil.getNumeroSerie());
        } else {
            System.out.println("No se ha dado de alta con el número de serie " + noriaInfantil.getNumeroSerie());
        }

        gestionParque.incrementarVisitantes(12344, 5000);
        gestionParque.incrementarVisitantes(56789, 10000);

        // Mostrar información de cada atracción
        System.out.println("\nInformación de Dragon Khan:");
        Atraccion infoDragonKhan = gestionParque.obtenerAtraccionPorNumeroDeSerie(12344);
        if (infoDragonKhan != null) {
            System.out.println(infoDragonKhan.toString() + "\n");
        } else {
            System.out.println("No existe ninguna atracción con el número de serie 12344");
        }

        System.out.println("Información de Noria Infantil:");
        Atraccion infoNoriaInfantil = gestionParque.obtenerAtraccionPorNumeroDeSerie(56789);
        if (infoNoriaInfantil != null) {
            System.out.println(infoNoriaInfantil.toString() + "\n");
        } else {
            System.out.println("No existe ninguna atracción con el número de serie 56789");
        }

        // Mostrar el número total de montañas rusas y velocidad máxima
        System.out.println("Número total de montañas rusas: " + gestionParque.obtenerNumeroTotalMontanasRusa());
        System.out.println("Velocidad máxima de las montañas rusas: " + gestionParque.obtenerVelocidadMaximaMontanaRusa());
    }
}
