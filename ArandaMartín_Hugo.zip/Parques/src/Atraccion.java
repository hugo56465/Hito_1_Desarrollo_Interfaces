
public abstract class Atraccion {
	private int numeroSerie;
	private String nombre;
	private ParqueAtracciones parqueAtracciones;
	private int numeroVisitantes;
	public Atraccion(int numeroSerie, String nombre, ParqueAtracciones parqueAtracciones) {
		super();
		this.numeroSerie = numeroSerie;
		this.nombre = nombre;
		this.parqueAtracciones = parqueAtracciones;
		this.numeroVisitantes = 0;
	}
	public int getNumeroSerie() {
		return numeroSerie;
	}
	public void setNumeroSerie(int numeroSerie) {
		this.numeroSerie = numeroSerie;
	}
	public String getNombre() {
		return nombre;
	}
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	public ParqueAtracciones getParqueAtracciones() {
		return parqueAtracciones;
	}
	public void setParqueAtracciones(ParqueAtracciones parqueAtracciones) {
		this.parqueAtracciones = parqueAtracciones;
	}
	public int getNumeroVisitantes() {
		return numeroVisitantes;
	}
	public void setNumeroVisitantes(int numeroVisitantes) {
		this.numeroVisitantes = numeroVisitantes;
	}
	public void incrementarVisitantes(int cantidad) {
        numeroVisitantes += cantidad;
    }
	@Override
	public String toString() {
		return "Atraccion [numeroSerie=" + numeroSerie + ", nombre=" + nombre + ", parqueAtracciones="
				+ parqueAtracciones + ", numeroVisitantes=" + numeroVisitantes + "]";
	}
	
}
