
public class Noria extends Atraccion {
	public enum TipoNoria {
        ADULTO, INFANTIL
    }
	private TipoNoria tipo;
	
	
	public Noria(int numeroSerie, String nombre, ParqueAtracciones parqueAtracciones, int numeroVisitantes, Noria.TipoNoria tipo) {
		super(numeroSerie, nombre, parqueAtracciones);
		this.tipo = tipo;
	}

	public Noria.TipoNoria getTipo() {
		return tipo;
	}

	public void setTipo(Noria.TipoNoria tipo) {
		this.tipo = tipo;
	}

	@Override
	public String toString() {
		return "Noria\n"+super.toString()+" [tipo=" + tipo + "]";
	}
	
}
